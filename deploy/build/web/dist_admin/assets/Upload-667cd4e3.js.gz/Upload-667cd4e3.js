import{bb as V,z as r,a3 as L,L as f,aq as R,M as E,T as C,aW as H,X as N,aY as le,a_ as se,aZ as de,aX as ce,O as ue,Q,bJ as Ce,aK as re,U as ge,ag as ke,ah as G,bd as ee,a9 as Be,ap as fe,k as W,a4 as Pe,aw as Te,N as Z,ai as $e,bt as Se,ar as te,as as j,au as Le,P as De,R as O,S as ze,aA as Ie,bK as Oe,ad as Fe,bL as Ue,bM as ie,W as je,Y as ne}from"./index-7e9df7d9.js";import{g as Ne,i as he,N as _e,d as Ae,a as Me,c as X,e as Ee,m as He,b as qe}from"./Image-77507ba9.js";import{A as We}from"./Add-3a899e67.js";import{E as Xe}from"./Input-5db271d7.js";const Ve=V("attach",r("svg",{viewBox:"0 0 16 16",version:"1.1",xmlns:"http://www.w3.org/2000/svg"},r("g",{stroke:"none","stroke-width":"1",fill:"none","fill-rule":"evenodd"},r("g",{fill:"currentColor","fill-rule":"nonzero"},r("path",{d:"M3.25735931,8.70710678 L7.85355339,4.1109127 C8.82986412,3.13460197 10.4127766,3.13460197 11.3890873,4.1109127 C12.365398,5.08722343 12.365398,6.67013588 11.3890873,7.64644661 L6.08578644,12.9497475 C5.69526215,13.3402718 5.06209717,13.3402718 4.67157288,12.9497475 C4.28104858,12.5592232 4.28104858,11.9260582 4.67157288,11.5355339 L9.97487373,6.23223305 C10.1701359,6.0369709 10.1701359,5.72038841 9.97487373,5.52512627 C9.77961159,5.32986412 9.4630291,5.32986412 9.26776695,5.52512627 L3.96446609,10.8284271 C3.18341751,11.6094757 3.18341751,12.8758057 3.96446609,13.6568542 C4.74551468,14.4379028 6.01184464,14.4379028 6.79289322,13.6568542 L12.0961941,8.35355339 C13.4630291,6.98671837 13.4630291,4.77064094 12.0961941,3.40380592 C10.7293591,2.0369709 8.51328163,2.0369709 7.14644661,3.40380592 L2.55025253,8 C2.35499039,8.19526215 2.35499039,8.51184464 2.55025253,8.70710678 C2.74551468,8.90236893 3.06209717,8.90236893 3.25735931,8.70710678 Z"}))))),Ge=V("trash",r("svg",{xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 512 512"},r("path",{d:"M432,144,403.33,419.74A32,32,0,0,1,371.55,448H140.46a32,32,0,0,1-31.78-28.26L80,144",style:"fill: none; stroke: currentcolor; stroke-linecap: round; stroke-linejoin: round; stroke-width: 32px;"}),r("rect",{x:"32",y:"64",width:"448",height:"80",rx:"16",ry:"16",style:"fill: none; stroke: currentcolor; stroke-linecap: round; stroke-linejoin: round; stroke-width: 32px;"}),r("line",{x1:"312",y1:"240",x2:"200",y2:"352",style:"fill: none; stroke: currentcolor; stroke-linecap: round; stroke-linejoin: round; stroke-width: 32px;"}),r("line",{x1:"312",y1:"352",x2:"200",y2:"240",style:"fill: none; stroke: currentcolor; stroke-linecap: round; stroke-linejoin: round; stroke-width: 32px;"}))),Ye=V("download",r("svg",{viewBox:"0 0 16 16",version:"1.1",xmlns:"http://www.w3.org/2000/svg"},r("g",{stroke:"none","stroke-width":"1",fill:"none","fill-rule":"evenodd"},r("g",{fill:"currentColor","fill-rule":"nonzero"},r("path",{d:"M3.5,13 L12.5,13 C12.7761424,13 13,13.2238576 13,13.5 C13,13.7454599 12.8231248,13.9496084 12.5898756,13.9919443 L12.5,14 L3.5,14 C3.22385763,14 3,13.7761424 3,13.5 C3,13.2545401 3.17687516,13.0503916 3.41012437,13.0080557 L3.5,13 L12.5,13 L3.5,13 Z M7.91012437,1.00805567 L8,1 C8.24545989,1 8.44960837,1.17687516 8.49194433,1.41012437 L8.5,1.5 L8.5,10.292 L11.1819805,7.6109127 C11.3555469,7.43734635 11.6249713,7.4180612 11.8198394,7.55305725 L11.8890873,7.6109127 C12.0626536,7.78447906 12.0819388,8.05390346 11.9469427,8.2487716 L11.8890873,8.31801948 L8.35355339,11.8535534 C8.17998704,12.0271197 7.91056264,12.0464049 7.7156945,11.9114088 L7.64644661,11.8535534 L4.1109127,8.31801948 C3.91565056,8.12275734 3.91565056,7.80617485 4.1109127,7.6109127 C4.28447906,7.43734635 4.55390346,7.4180612 4.7487716,7.55305725 L4.81801948,7.6109127 L7.5,10.292 L7.5,1.5 C7.5,1.25454011 7.67687516,1.05039163 7.91012437,1.00805567 L8,1 L7.91012437,1.00805567 Z"}))))),Ke=V("cancel",r("svg",{viewBox:"0 0 16 16",version:"1.1",xmlns:"http://www.w3.org/2000/svg"},r("g",{stroke:"none","stroke-width":"1",fill:"none","fill-rule":"evenodd"},r("g",{fill:"currentColor","fill-rule":"nonzero"},r("path",{d:"M2.58859116,2.7156945 L2.64644661,2.64644661 C2.82001296,2.47288026 3.08943736,2.45359511 3.2843055,2.58859116 L3.35355339,2.64644661 L8,7.293 L12.6464466,2.64644661 C12.8417088,2.45118446 13.1582912,2.45118446 13.3535534,2.64644661 C13.5488155,2.84170876 13.5488155,3.15829124 13.3535534,3.35355339 L8.707,8 L13.3535534,12.6464466 C13.5271197,12.820013 13.5464049,13.0894374 13.4114088,13.2843055 L13.3535534,13.3535534 C13.179987,13.5271197 12.9105626,13.5464049 12.7156945,13.4114088 L12.6464466,13.3535534 L8,8.707 L3.35355339,13.3535534 C3.15829124,13.5488155 2.84170876,13.5488155 2.64644661,13.3535534 C2.45118446,13.1582912 2.45118446,12.8417088 2.64644661,12.6464466 L7.293,8 L2.64644661,3.35355339 C2.47288026,3.17998704 2.45359511,2.91056264 2.58859116,2.7156945 L2.64644661,2.64644661 L2.58859116,2.7156945 Z"}))))),Ze=V("retry",r("svg",{xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 512 512"},r("path",{d:"M320,146s24.36-12-64-12A160,160,0,1,0,416,294",style:"fill: none; stroke: currentcolor; stroke-linecap: round; stroke-miterlimit: 10; stroke-width: 32px;"}),r("polyline",{points:"256 58 336 138 256 218",style:"fill: none; stroke: currentcolor; stroke-linecap: round; stroke-linejoin: round; stroke-width: 32px;"}))),Je=L([f("progress",{display:"inline-block"},[f("progress-icon",`
 color: var(--n-icon-color);
 transition: color .3s var(--n-bezier);
 `),R("line",`
 width: 100%;
 display: block;
 `,[f("progress-content",`
 display: flex;
 align-items: center;
 `,[f("progress-graph",{flex:1})]),f("progress-custom-content",{marginLeft:"14px"}),f("progress-icon",`
 width: 30px;
 padding-left: 14px;
 height: var(--n-icon-size-line);
 line-height: var(--n-icon-size-line);
 font-size: var(--n-icon-size-line);
 `,[R("as-text",`
 color: var(--n-text-color-line-outer);
 text-align: center;
 width: 40px;
 font-size: var(--n-font-size);
 padding-left: 4px;
 transition: color .3s var(--n-bezier);
 `)])]),R("circle, dashboard",{width:"120px"},[f("progress-custom-content",`
 position: absolute;
 left: 50%;
 top: 50%;
 transform: translateX(-50%) translateY(-50%);
 display: flex;
 align-items: center;
 justify-content: center;
 `),f("progress-text",`
 position: absolute;
 left: 50%;
 top: 50%;
 transform: translateX(-50%) translateY(-50%);
 display: flex;
 align-items: center;
 color: inherit;
 font-size: var(--n-font-size-circle);
 color: var(--n-text-color-circle);
 font-weight: var(--n-font-weight-circle);
 transition: color .3s var(--n-bezier);
 white-space: nowrap;
 `),f("progress-icon",`
 position: absolute;
 left: 50%;
 top: 50%;
 transform: translateX(-50%) translateY(-50%);
 display: flex;
 align-items: center;
 color: var(--n-icon-color);
 font-size: var(--n-icon-size-circle);
 `)]),R("multiple-circle",`
 width: 200px;
 color: inherit;
 `,[f("progress-text",`
 font-weight: var(--n-font-weight-circle);
 color: var(--n-text-color-circle);
 position: absolute;
 left: 50%;
 top: 50%;
 transform: translateX(-50%) translateY(-50%);
 display: flex;
 align-items: center;
 justify-content: center;
 transition: color .3s var(--n-bezier);
 `)]),f("progress-content",{position:"relative"}),f("progress-graph",{position:"relative"},[f("progress-graph-circle",[L("svg",{verticalAlign:"bottom"}),f("progress-graph-circle-fill",`
 stroke: var(--n-fill-color);
 transition:
 opacity .3s var(--n-bezier),
 stroke .3s var(--n-bezier),
 stroke-dasharray .3s var(--n-bezier);
 `,[R("empty",{opacity:0})]),f("progress-graph-circle-rail",`
 transition: stroke .3s var(--n-bezier);
 overflow: hidden;
 stroke: var(--n-rail-color);
 `)]),f("progress-graph-line",[R("indicator-inside",[f("progress-graph-line-rail",`
 height: 16px;
 line-height: 16px;
 border-radius: 10px;
 `,[f("progress-graph-line-fill",`
 height: inherit;
 border-radius: 10px;
 `),f("progress-graph-line-indicator",`
 background: #0000;
 white-space: nowrap;
 text-align: right;
 margin-left: 14px;
 margin-right: 14px;
 height: inherit;
 font-size: 12px;
 color: var(--n-text-color-line-inner);
 transition: color .3s var(--n-bezier);
 `)])]),R("indicator-inside-label",`
 height: 16px;
 display: flex;
 align-items: center;
 `,[f("progress-graph-line-rail",`
 flex: 1;
 transition: background-color .3s var(--n-bezier);
 `),f("progress-graph-line-indicator",`
 background: var(--n-fill-color);
 font-size: 12px;
 transform: translateZ(0);
 display: flex;
 vertical-align: middle;
 height: 16px;
 line-height: 16px;
 padding: 0 10px;
 border-radius: 10px;
 position: absolute;
 white-space: nowrap;
 color: var(--n-text-color-line-inner);
 transition:
 right .2s var(--n-bezier),
 color .3s var(--n-bezier),
 background-color .3s var(--n-bezier);
 `)]),f("progress-graph-line-rail",`
 position: relative;
 overflow: hidden;
 height: var(--n-rail-height);
 border-radius: 5px;
 background-color: var(--n-rail-color);
 transition: background-color .3s var(--n-bezier);
 `,[f("progress-graph-line-fill",`
 background: var(--n-fill-color);
 position: relative;
 border-radius: 5px;
 height: inherit;
 width: 100%;
 max-width: 0%;
 transition:
 background-color .3s var(--n-bezier),
 max-width .2s var(--n-bezier);
 `,[R("processing",[L("&::after",`
 content: "";
 background-image: var(--n-line-bg-processing);
 animation: progress-processing-animation 2s var(--n-bezier) infinite;
 `)])])])])])]),L("@keyframes progress-processing-animation",`
 0% {
 position: absolute;
 left: 0;
 top: 0;
 bottom: 0;
 right: 100%;
 opacity: 1;
 }
 66% {
 position: absolute;
 left: 0;
 top: 0;
 bottom: 0;
 right: 0;
 opacity: 0;
 }
 100% {
 position: absolute;
 left: 0;
 top: 0;
 bottom: 0;
 right: 0;
 opacity: 0;
 }
 `)]),Qe={success:r(le,null),error:r(se,null),warning:r(de,null),info:r(ce,null)},er=E({name:"ProgressLine",props:{clsPrefix:{type:String,required:!0},percentage:{type:Number,default:0},railColor:String,railStyle:[String,Object],fillColor:String,status:{type:String,required:!0},indicatorPlacement:{type:String,required:!0},indicatorTextColor:String,unit:{type:String,default:"%"},processing:{type:Boolean,required:!0},showIndicator:{type:Boolean,required:!0},height:[String,Number],railBorderRadius:[String,Number],fillBorderRadius:[String,Number]},setup(e,{slots:i}){const n=C(()=>H(e.height)),t=C(()=>e.railBorderRadius!==void 0?H(e.railBorderRadius):e.height!==void 0?H(e.height,{c:.5}):""),o=C(()=>e.fillBorderRadius!==void 0?H(e.fillBorderRadius):e.railBorderRadius!==void 0?H(e.railBorderRadius):e.height!==void 0?H(e.height,{c:.5}):"");return()=>{const{indicatorPlacement:s,railColor:u,railStyle:m,percentage:d,unit:l,indicatorTextColor:a,status:c,showIndicator:y,fillColor:h,processing:k,clsPrefix:v}=e;return r("div",{class:`${v}-progress-content`,role:"none"},r("div",{class:`${v}-progress-graph`,"aria-hidden":!0},r("div",{class:[`${v}-progress-graph-line`,{[`${v}-progress-graph-line--indicator-${s}`]:!0}]},r("div",{class:`${v}-progress-graph-line-rail`,style:[{backgroundColor:u,height:n.value,borderRadius:t.value},m]},r("div",{class:[`${v}-progress-graph-line-fill`,k&&`${v}-progress-graph-line-fill--processing`],style:{maxWidth:`${e.percentage}%`,backgroundColor:h,height:n.value,lineHeight:n.value,borderRadius:o.value}},s==="inside"?r("div",{class:`${v}-progress-graph-line-indicator`,style:{color:a}},i.default?i.default():`${d}${l}`):null)))),y&&s==="outside"?r("div",null,i.default?r("div",{class:`${v}-progress-custom-content`,style:{color:a},role:"none"},i.default()):c==="default"?r("div",{role:"none",class:`${v}-progress-icon ${v}-progress-icon--as-text`,style:{color:a}},d,l):r("div",{class:`${v}-progress-icon`,"aria-hidden":!0},r(N,{clsPrefix:v},{default:()=>Qe[c]}))):null)}}}),rr={success:r(le,null),error:r(se,null),warning:r(de,null),info:r(ce,null)},tr=E({name:"ProgressCircle",props:{clsPrefix:{type:String,required:!0},status:{type:String,required:!0},strokeWidth:{type:Number,required:!0},fillColor:String,railColor:String,railStyle:[String,Object],percentage:{type:Number,default:0},offsetDegree:{type:Number,default:0},showIndicator:{type:Boolean,required:!0},indicatorTextColor:String,unit:String,viewBoxWidth:{type:Number,required:!0},gapDegree:{type:Number,required:!0},gapOffsetDegree:{type:Number,default:0}},setup(e,{slots:i}){function n(t,o,s){const{gapDegree:u,viewBoxWidth:m,strokeWidth:d}=e,l=50,a=0,c=l,y=0,h=2*l,k=50+d/2,v=`M ${k},${k} m ${a},${c}
      a ${l},${l} 0 1 1 ${y},${-h}
      a ${l},${l} 0 1 1 ${-y},${h}`,B=Math.PI*2*l,D={stroke:s,strokeDasharray:`${t/100*(B-u)}px ${m*8}px`,strokeDashoffset:`-${u/2}px`,transformOrigin:o?"center":void 0,transform:o?`rotate(${o}deg)`:void 0};return{pathString:v,pathStyle:D}}return()=>{const{fillColor:t,railColor:o,strokeWidth:s,offsetDegree:u,status:m,percentage:d,showIndicator:l,indicatorTextColor:a,unit:c,gapOffsetDegree:y,clsPrefix:h}=e,{pathString:k,pathStyle:v}=n(100,0,o),{pathString:B,pathStyle:D}=n(d,u,t),T=100+s;return r("div",{class:`${h}-progress-content`,role:"none"},r("div",{class:`${h}-progress-graph`,"aria-hidden":!0},r("div",{class:`${h}-progress-graph-circle`,style:{transform:y?`rotate(${y}deg)`:void 0}},r("svg",{viewBox:`0 0 ${T} ${T}`},r("g",null,r("path",{class:`${h}-progress-graph-circle-rail`,d:k,"stroke-width":s,"stroke-linecap":"round",fill:"none",style:v})),r("g",null,r("path",{class:[`${h}-progress-graph-circle-fill`,d===0&&`${h}-progress-graph-circle-fill--empty`],d:B,"stroke-width":s,"stroke-linecap":"round",fill:"none",style:D}))))),l?r("div",null,i.default?r("div",{class:`${h}-progress-custom-content`,role:"none"},i.default()):m!=="default"?r("div",{class:`${h}-progress-icon`,"aria-hidden":!0},r(N,{clsPrefix:h},{default:()=>rr[m]})):r("div",{class:`${h}-progress-text`,style:{color:a},role:"none"},r("span",{class:`${h}-progress-text__percentage`},d),r("span",{class:`${h}-progress-text__unit`},c))):null)}}});function oe(e,i,n=100){return`m ${n/2} ${n/2-e} a ${e} ${e} 0 1 1 0 ${2*e} a ${e} ${e} 0 1 1 0 -${2*e}`}const ir=E({name:"ProgressMultipleCircle",props:{clsPrefix:{type:String,required:!0},viewBoxWidth:{type:Number,required:!0},percentage:{type:Array,default:[0]},strokeWidth:{type:Number,required:!0},circleGap:{type:Number,required:!0},showIndicator:{type:Boolean,required:!0},fillColor:{type:Array,default:()=>[]},railColor:{type:Array,default:()=>[]},railStyle:{type:Array,default:()=>[]}},setup(e,{slots:i}){const n=C(()=>e.percentage.map((o,s)=>`${Math.PI*o/100*(e.viewBoxWidth/2-e.strokeWidth/2*(1+2*s)-e.circleGap*s)*2}, ${e.viewBoxWidth*8}`));return()=>{const{viewBoxWidth:t,strokeWidth:o,circleGap:s,showIndicator:u,fillColor:m,railColor:d,railStyle:l,percentage:a,clsPrefix:c}=e;return r("div",{class:`${c}-progress-content`,role:"none"},r("div",{class:`${c}-progress-graph`,"aria-hidden":!0},r("div",{class:`${c}-progress-graph-circle`},r("svg",{viewBox:`0 0 ${t} ${t}`},a.map((y,h)=>r("g",{key:h},r("path",{class:`${c}-progress-graph-circle-rail`,d:oe(t/2-o/2*(1+2*h)-s*h,o,t),"stroke-width":o,"stroke-linecap":"round",fill:"none",style:[{strokeDashoffset:0,stroke:d[h]},l[h]]}),r("path",{class:[`${c}-progress-graph-circle-fill`,y===0&&`${c}-progress-graph-circle-fill--empty`],d:oe(t/2-o/2*(1+2*h)-s*h,o,t),"stroke-width":o,"stroke-linecap":"round",fill:"none",style:{strokeDasharray:n.value[h],strokeDashoffset:0,stroke:m[h]}})))))),u&&i.default?r("div",null,r("div",{class:`${c}-progress-text`},i.default())):null)}}}),nr=Object.assign(Object.assign({},Q.props),{processing:Boolean,type:{type:String,default:"line"},gapDegree:Number,gapOffsetDegree:Number,status:{type:String,default:"default"},railColor:[String,Array],railStyle:[String,Array],color:[String,Array],viewBoxWidth:{type:Number,default:100},strokeWidth:{type:Number,default:7},percentage:[Number,Array],unit:{type:String,default:"%"},showIndicator:{type:Boolean,default:!0},indicatorPosition:{type:String,default:"outside"},indicatorPlacement:{type:String,default:"outside"},indicatorTextColor:String,circleGap:{type:Number,default:1},height:Number,borderRadius:[String,Number],fillBorderRadius:[String,Number],offsetDegree:Number}),or=E({name:"Progress",props:nr,setup(e){const i=C(()=>e.indicatorPlacement||e.indicatorPosition),n=C(()=>{if(e.gapDegree||e.gapDegree===0)return e.gapDegree;if(e.type==="dashboard")return 75}),{mergedClsPrefixRef:t,inlineThemeDisabled:o}=ue(e),s=Q("Progress","-progress",Je,Ce,e,t),u=C(()=>{const{status:d}=e,{common:{cubicBezierEaseInOut:l},self:{fontSize:a,fontSizeCircle:c,railColor:y,railHeight:h,iconSizeCircle:k,iconSizeLine:v,textColorCircle:B,textColorLineInner:D,textColorLineOuter:T,lineBgProcessing:x,fontWeightCircle:$,[re("iconColor",d)]:p,[re("fillColor",d)]:b}}=s.value;return{"--n-bezier":l,"--n-fill-color":b,"--n-font-size":a,"--n-font-size-circle":c,"--n-font-weight-circle":$,"--n-icon-color":p,"--n-icon-size-circle":k,"--n-icon-size-line":v,"--n-line-bg-processing":x,"--n-rail-color":y,"--n-rail-height":h,"--n-text-color-circle":B,"--n-text-color-line-inner":D,"--n-text-color-line-outer":T}}),m=o?ge("progress",C(()=>e.status[0]),u,e):void 0;return{mergedClsPrefix:t,mergedIndicatorPlacement:i,gapDeg:n,cssVars:o?void 0:u,themeClass:m==null?void 0:m.themeClass,onRender:m==null?void 0:m.onRender}},render(){const{type:e,cssVars:i,indicatorTextColor:n,showIndicator:t,status:o,railColor:s,railStyle:u,color:m,percentage:d,viewBoxWidth:l,strokeWidth:a,mergedIndicatorPlacement:c,unit:y,borderRadius:h,fillBorderRadius:k,height:v,processing:B,circleGap:D,mergedClsPrefix:T,gapDeg:x,gapOffsetDegree:$,themeClass:p,$slots:b,onRender:w}=this;return w==null||w(),r("div",{class:[p,`${T}-progress`,`${T}-progress--${e}`,`${T}-progress--${o}`],style:i,"aria-valuemax":100,"aria-valuemin":0,"aria-valuenow":d,role:e==="circle"||e==="line"||e==="dashboard"?"progressbar":"none"},e==="circle"||e==="dashboard"?r(tr,{clsPrefix:T,status:o,showIndicator:t,indicatorTextColor:n,railColor:s,fillColor:m,railStyle:u,offsetDegree:this.offsetDegree,percentage:d,viewBoxWidth:l,strokeWidth:a,gapDegree:x===void 0?e==="dashboard"?75:0:x,gapOffsetDegree:$,unit:y},b):e==="line"?r(er,{clsPrefix:T,status:o,showIndicator:t,indicatorTextColor:n,railColor:s,fillColor:m,railStyle:u,percentage:d,processing:B,indicatorPlacement:c,unit:y,fillBorderRadius:k,railBorderRadius:h,height:v},b):e==="multiple-circle"?r(ir,{clsPrefix:T,strokeWidth:a,railColor:s,fillColor:m,railStyle:u,viewBoxWidth:l,percentage:d,showIndicator:t,circleGap:D},b):null)}}),q=ke("n-upload"),pe="__UPLOAD_DRAGGER__",ar=E({name:"UploadDragger",[pe]:!0,setup(e,{slots:i}){const n=G(q,null);return n||ee("upload-dragger","`n-upload-dragger` must be placed inside `n-upload`."),()=>{const{mergedClsPrefixRef:{value:t},mergedDisabledRef:{value:o},maxReachedRef:{value:s}}=n;return r("div",{class:[`${t}-upload-dragger`,(o||s)&&`${t}-upload-dragger--disabled`]},i)}}}),me=E({name:"UploadTrigger",props:{abstract:Boolean},setup(e,{slots:i}){const n=G(q,null);n||ee("upload-trigger","`n-upload-trigger` must be placed inside `n-upload`.");const{mergedClsPrefixRef:t,mergedDisabledRef:o,maxReachedRef:s,listTypeRef:u,dragOverRef:m,openOpenFileDialog:d,draggerInsideRef:l,handleFileAddition:a,mergedDirectoryDndRef:c,triggerStyleRef:y}=n,h=C(()=>u.value==="image-card");function k(){o.value||s.value||d()}function v(x){x.preventDefault(),m.value=!0}function B(x){x.preventDefault(),m.value=!0}function D(x){x.preventDefault(),m.value=!1}function T(x){var $;if(x.preventDefault(),!l.value||o.value||s.value){m.value=!1;return}const p=($=x.dataTransfer)===null||$===void 0?void 0:$.items;p!=null&&p.length?Ne(Array.from(p).map(b=>b.webkitGetAsEntry()),c.value).then(b=>{a(b)}).finally(()=>{m.value=!1}):m.value=!1}return()=>{var x;const{value:$}=t;return e.abstract?(x=i.default)===null||x===void 0?void 0:x.call(i,{handleClick:k,handleDrop:T,handleDragOver:v,handleDragEnter:B,handleDragLeave:D}):r("div",{class:[`${$}-upload-trigger`,(o.value||s.value)&&`${$}-upload-trigger--disabled`,h.value&&`${$}-upload-trigger--image-card`],style:y.value,onClick:k,onDrop:T,onDragover:v,onDragenter:B,onDragleave:D},h.value?r(ar,null,{default:()=>Be(i.default,()=>[r(N,{clsPrefix:$},{default:()=>r(We,null)})])}):i)}}}),lr=E({name:"UploadProgress",props:{show:Boolean,percentage:{type:Number,required:!0},status:{type:String,required:!0}},setup(){return{mergedTheme:G(q).mergedThemeRef}},render(){return r(fe,null,{default:()=>this.show?r(or,{type:"line",showIndicator:!1,percentage:this.percentage,status:this.status,height:2,theme:this.mergedTheme.peers.Progress,themeOverrides:this.mergedTheme.peerOverrides.Progress}):null})}}),sr=r("svg",{xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 28 28"},r("g",{fill:"none"},r("path",{d:"M21.75 3A3.25 3.25 0 0 1 25 6.25v15.5A3.25 3.25 0 0 1 21.75 25H6.25A3.25 3.25 0 0 1 3 21.75V6.25A3.25 3.25 0 0 1 6.25 3h15.5zm.583 20.4l-7.807-7.68a.75.75 0 0 0-.968-.07l-.084.07l-7.808 7.68c.183.065.38.1.584.1h15.5c.204 0 .4-.035.583-.1l-7.807-7.68l7.807 7.68zM21.75 4.5H6.25A1.75 1.75 0 0 0 4.5 6.25v15.5c0 .208.036.408.103.593l7.82-7.692a2.25 2.25 0 0 1 3.026-.117l.129.117l7.82 7.692c.066-.185.102-.385.102-.593V6.25a1.75 1.75 0 0 0-1.75-1.75zm-3.25 3a2.5 2.5 0 1 1 0 5a2.5 2.5 0 0 1 0-5zm0 1.5a1 1 0 1 0 0 2a1 1 0 0 0 0-2z",fill:"currentColor"}))),dr=r("svg",{xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 28 28"},r("g",{fill:"none"},r("path",{d:"M6.4 2A2.4 2.4 0 0 0 4 4.4v19.2A2.4 2.4 0 0 0 6.4 26h15.2a2.4 2.4 0 0 0 2.4-2.4V11.578c0-.729-.29-1.428-.805-1.944l-6.931-6.931A2.4 2.4 0 0 0 14.567 2H6.4zm-.9 2.4a.9.9 0 0 1 .9-.9H14V10a2 2 0 0 0 2 2h6.5v11.6a.9.9 0 0 1-.9.9H6.4a.9.9 0 0 1-.9-.9V4.4zm16.44 6.1H16a.5.5 0 0 1-.5-.5V4.06l6.44 6.44z",fill:"currentColor"})));var cr=globalThis&&globalThis.__awaiter||function(e,i,n,t){function o(s){return s instanceof n?s:new n(function(u){u(s)})}return new(n||(n=Promise))(function(s,u){function m(a){try{l(t.next(a))}catch(c){u(c)}}function d(a){try{l(t.throw(a))}catch(c){u(c)}}function l(a){a.done?s(a.value):o(a.value).then(m,d)}l((t=t.apply(e,i||[])).next())})};const J={paddingMedium:"0 3px",heightMedium:"24px",iconSizeMedium:"18px"},ur=E({name:"UploadFile",props:{clsPrefix:{type:String,required:!0},file:{type:Object,required:!0},listType:{type:String,required:!0}},setup(e){const i=G(q),n=W(null),t=W(""),o=C(()=>{const{file:p}=e;return p.status==="finished"?"success":p.status==="error"?"error":"info"}),s=C(()=>{const{file:p}=e;if(p.status==="error")return"error"}),u=C(()=>{const{file:p}=e;return p.status==="uploading"}),m=C(()=>{if(!i.showCancelButtonRef.value)return!1;const{file:p}=e;return["uploading","pending","error"].includes(p.status)}),d=C(()=>{if(!i.showRemoveButtonRef.value)return!1;const{file:p}=e;return["finished"].includes(p.status)}),l=C(()=>{if(!i.showDownloadButtonRef.value)return!1;const{file:p}=e;return["finished"].includes(p.status)}),a=C(()=>{if(!i.showRetryButtonRef.value)return!1;const{file:p}=e;return["error"].includes(p.status)}),c=Pe(()=>t.value||e.file.thumbnailUrl||e.file.url),y=C(()=>{if(!i.showPreviewButtonRef.value)return!1;const{file:{status:p},listType:b}=e;return["finished"].includes(p)&&c.value&&b==="image-card"});function h(){i.submit(e.file.id)}function k(p){p.preventDefault();const{file:b}=e;["finished","pending","error"].includes(b.status)?B(b):["uploading"].includes(b.status)?T(b):Se("upload","The button clicked type is unknown.")}function v(p){p.preventDefault(),D(e.file)}function B(p){const{xhrMap:b,doChange:w,onRemoveRef:{value:Y},mergedFileListRef:{value:g}}=i;Promise.resolve(Y?Y({file:Object.assign({},p),fileList:g}):!0).then(P=>{if(P===!1)return;const S=Object.assign({},p,{status:"removed"});b.delete(p.id),w(S,void 0,{remove:!0})})}function D(p){const{onDownloadRef:{value:b}}=i;Promise.resolve(b?b(Object.assign({},p)):!0).then(w=>{w!==!1&&Ae(p.url,p.name)})}function T(p){const{xhrMap:b}=i,w=b.get(p.id);w==null||w.abort(),B(Object.assign({},p))}function x(){const{onPreviewRef:{value:p}}=i;if(p)p(e.file);else if(e.listType==="image-card"){const{value:b}=n;if(!b)return;b.click()}}const $=()=>cr(this,void 0,void 0,function*(){const{listType:p}=e;p!=="image"&&p!=="image-card"||i.shouldUseThumbnailUrlRef.value(e.file)&&(t.value=yield i.getFileThumbnailUrlResolver(e.file))});return Te(()=>{$()}),{mergedTheme:i.mergedThemeRef,progressStatus:o,buttonType:s,showProgress:u,disabled:i.mergedDisabledRef,showCancelButton:m,showRemoveButton:d,showDownloadButton:l,showRetryButton:a,showPreviewButton:y,mergedThumbnailUrl:c,shouldUseThumbnailUrl:i.shouldUseThumbnailUrlRef,renderIcon:i.renderIconRef,imageRef:n,handleRemoveOrCancelClick:k,handleDownloadClick:v,handleRetryClick:h,handlePreviewClick:x}},render(){const{clsPrefix:e,mergedTheme:i,listType:n,file:t,renderIcon:o}=this;let s;const u=n==="image";u||n==="image-card"?s=!this.shouldUseThumbnailUrl(t)||!this.mergedThumbnailUrl?r("span",{class:`${e}-upload-file-info__thumbnail`},o?o(t):he(t)?r(N,{clsPrefix:e},{default:()=>sr}):r(N,{clsPrefix:e},{default:()=>dr})):r("a",{rel:"noopener noreferer",target:"_blank",href:t.url||void 0,class:`${e}-upload-file-info__thumbnail`,onClick:this.handlePreviewClick},n==="image-card"?r(_e,{src:this.mergedThumbnailUrl||void 0,previewSrc:t.url||void 0,alt:t.name,ref:"imageRef"}):r("img",{src:this.mergedThumbnailUrl||void 0,alt:t.name})):s=r("span",{class:`${e}-upload-file-info__thumbnail`},o?o(t):r(N,{clsPrefix:e},{default:()=>r(Ve,null)}));const d=r(lr,{show:this.showProgress,percentage:t.percentage||0,status:this.progressStatus}),l=n==="text"||n==="image";return r("div",{class:[`${e}-upload-file`,`${e}-upload-file--${this.progressStatus}-status`,t.url&&t.status!=="error"&&n!=="image-card"&&`${e}-upload-file--with-url`,`${e}-upload-file--${n}-type`]},r("div",{class:`${e}-upload-file-info`},s,r("div",{class:`${e}-upload-file-info__name`},l&&(t.url&&t.status!=="error"?r("a",{rel:"noopener noreferer",target:"_blank",href:t.url||void 0,onClick:this.handlePreviewClick},t.name):r("span",{onClick:this.handlePreviewClick},t.name)),u&&d),r("div",{class:[`${e}-upload-file-info__action`,`${e}-upload-file-info__action--${n}-type`]},this.showPreviewButton?r(Z,{key:"preview",quaternary:!0,type:this.buttonType,onClick:this.handlePreviewClick,theme:i.peers.Button,themeOverrides:i.peerOverrides.Button,builtinThemeOverrides:J},{icon:()=>r(N,{clsPrefix:e},{default:()=>r(Xe,null)})}):null,(this.showRemoveButton||this.showCancelButton)&&!this.disabled&&r(Z,{key:"cancelOrTrash",theme:i.peers.Button,themeOverrides:i.peerOverrides.Button,quaternary:!0,builtinThemeOverrides:J,type:this.buttonType,onClick:this.handleRemoveOrCancelClick},{icon:()=>r($e,null,{default:()=>this.showRemoveButton?r(N,{clsPrefix:e,key:"trash"},{default:()=>r(Ge,null)}):r(N,{clsPrefix:e,key:"cancel"},{default:()=>r(Ke,null)})})}),this.showRetryButton&&!this.disabled&&r(Z,{key:"retry",quaternary:!0,type:this.buttonType,onClick:this.handleRetryClick,theme:i.peers.Button,themeOverrides:i.peerOverrides.Button,builtinThemeOverrides:J},{icon:()=>r(N,{clsPrefix:e},{default:()=>r(Ze,null)})}),this.showDownloadButton?r(Z,{key:"download",quaternary:!0,type:this.buttonType,onClick:this.handleDownloadClick,theme:i.peers.Button,themeOverrides:i.peerOverrides.Button,builtinThemeOverrides:J},{icon:()=>r(N,{clsPrefix:e},{default:()=>r(Ye,null)})}):null)),!u&&d)}}),gr=E({name:"UploadFileList",setup(e,{slots:i}){const n=G(q,null);n||ee("upload-file-list","`n-upload-file-list` must be placed inside `n-upload`.");const{abstractRef:t,mergedClsPrefixRef:o,listTypeRef:s,mergedFileListRef:u,fileListStyleRef:m,cssVarsRef:d,themeClassRef:l,maxReachedRef:a,showTriggerRef:c,imageGroupPropsRef:y}=n,h=C(()=>s.value==="image-card"),k=()=>u.value.map(B=>r(ur,{clsPrefix:o.value,key:B.id,file:B,listType:s.value})),v=()=>h.value?r(Me,Object.assign({},y.value),{default:k}):r(fe,{group:!0},{default:k});return()=>{const{value:B}=o,{value:D}=t;return r("div",{class:[`${B}-upload-file-list`,h.value&&`${B}-upload-file-list--grid`,D?l==null?void 0:l.value:void 0],style:[D&&d?d.value:"",m.value]},v(),c.value&&!a.value&&h.value&&r(me,null,i))}}}),fr=L([f("upload","width: 100%;",[R("dragger-inside",[f("upload-trigger",`
 display: block;
 `)]),R("drag-over",[f("upload-dragger",`
 border: var(--n-dragger-border-hover);
 `)])]),f("upload-dragger",`
 cursor: pointer;
 box-sizing: border-box;
 width: 100%;
 text-align: center;
 border-radius: var(--n-border-radius);
 padding: 24px;
 opacity: 1;
 transition:
 opacity .3s var(--n-bezier),
 border-color .3s var(--n-bezier),
 background-color .3s var(--n-bezier);
 background-color: var(--n-dragger-color);
 border: var(--n-dragger-border);
 `,[L("&:hover",`
 border: var(--n-dragger-border-hover);
 `),R("disabled",`
 cursor: not-allowed;
 `)]),f("upload-trigger",`
 display: inline-block;
 box-sizing: border-box;
 opacity: 1;
 transition: opacity .3s var(--n-bezier);
 `,[L("+",[f("upload-file-list","margin-top: 8px;")]),R("disabled",`
 opacity: var(--n-item-disabled-opacity);
 cursor: not-allowed;
 `),R("image-card",`
 width: 96px;
 height: 96px;
 `,[f("base-icon",`
 font-size: 24px;
 `),f("upload-dragger",`
 padding: 0;
 height: 100%;
 width: 100%;
 display: flex;
 align-items: center;
 justify-content: center;
 `)])]),f("upload-file-list",`
 line-height: var(--n-line-height);
 opacity: 1;
 transition: opacity .3s var(--n-bezier);
 `,[L("a, img","outline: none;"),R("disabled",`
 opacity: var(--n-item-disabled-opacity);
 cursor: not-allowed;
 `,[f("upload-file","cursor: not-allowed;")]),R("grid",`
 display: grid;
 grid-template-columns: repeat(auto-fill, 96px);
 grid-gap: 8px;
 margin-top: 0;
 `),f("upload-file",`
 display: block;
 box-sizing: border-box;
 cursor: default;
 padding: 0px 12px 0 6px;
 transition: background-color .3s var(--n-bezier);
 border-radius: var(--n-border-radius);
 `,[te(),f("progress",[te({foldPadding:!0})]),L("&:hover",`
 background-color: var(--n-item-color-hover);
 `,[f("upload-file-info",[j("action",`
 opacity: 1;
 `)])]),R("image-type",`
 border-radius: var(--n-border-radius);
 text-decoration: underline;
 text-decoration-color: #0000;
 `,[f("upload-file-info",`
 padding-top: 0px;
 padding-bottom: 0px;
 width: 100%;
 height: 100%;
 display: flex;
 justify-content: space-between;
 align-items: center;
 padding: 6px 0;
 `,[f("progress",`
 padding: 2px 0;
 margin-bottom: 0;
 `),j("name",`
 padding: 0 8px;
 `),j("thumbnail",`
 width: 32px;
 height: 32px;
 font-size: 28px;
 display: flex;
 justify-content: center;
 align-items: center;
 `,[L("img",`
 width: 100%;
 `)])])]),R("text-type",[f("progress",`
 box-sizing: border-box;
 padding-bottom: 6px;
 margin-bottom: 6px;
 `)]),R("image-card-type",`
 position: relative;
 width: 96px;
 height: 96px;
 border: var(--n-item-border-image-card);
 border-radius: var(--n-border-radius);
 padding: 0;
 display: flex;
 align-items: center;
 justify-content: center;
 transition: border-color .3s var(--n-bezier), background-color .3s var(--n-bezier);
 border-radius: var(--n-border-radius);
 overflow: hidden;
 `,[f("progress",`
 position: absolute;
 left: 8px;
 bottom: 8px;
 right: 8px;
 width: unset;
 `),f("upload-file-info",`
 padding: 0;
 width: 100%;
 height: 100%;
 `,[j("thumbnail",`
 width: 100%;
 height: 100%;
 display: flex;
 flex-direction: column;
 align-items: center;
 justify-content: center;
 font-size: 36px;
 `,[L("img",`
 width: 100%;
 `)])]),L("&::before",`
 position: absolute;
 z-index: 1;
 left: 0;
 right: 0;
 top: 0;
 bottom: 0;
 border-radius: inherit;
 opacity: 0;
 transition: opacity .2s var(--n-bezier);
 content: "";
 `),L("&:hover",[L("&::before","opacity: 1;"),f("upload-file-info",[j("thumbnail","opacity: .12;")])])]),R("error-status",[L("&:hover",`
 background-color: var(--n-item-color-hover-error);
 `),f("upload-file-info",[j("name","color: var(--n-item-text-color-error);"),j("thumbnail","color: var(--n-item-text-color-error);")]),R("image-card-type",`
 border: var(--n-item-border-image-card-error);
 `)]),R("with-url",`
 cursor: pointer;
 `,[f("upload-file-info",[j("name",`
 color: var(--n-item-text-color-success);
 text-decoration-color: var(--n-item-text-color-success);
 `,[L("a",`
 text-decoration: underline;
 `)])])]),f("upload-file-info",`
 position: relative;
 padding-top: 6px;
 padding-bottom: 6px;
 display: flex;
 flex-wrap: nowrap;
 `,[j("thumbnail",`
 font-size: 18px;
 opacity: 1;
 transition: opacity .2s var(--n-bezier);
 color: var(--n-item-icon-color);
 `,[f("base-icon",`
 margin-right: 2px;
 vertical-align: middle;
 transition: color .3s var(--n-bezier);
 `)]),j("action",`
 padding-top: inherit;
 padding-bottom: inherit;
 position: absolute;
 right: 0;
 top: 0;
 bottom: 0;
 width: 80px;
 display: flex;
 align-items: center;
 transition: opacity .2s var(--n-bezier);
 justify-content: flex-end;
 opacity: 0;
 `,[f("button",[L("&:not(:last-child)",{marginRight:"4px"}),f("base-icon",[L("svg",[Le()])])]),R("image-type",`
 position: relative;
 max-width: 80px;
 width: auto;
 `),R("image-card-type",`
 z-index: 2;
 position: absolute;
 width: 100%;
 height: 100%;
 left: 0;
 right: 0;
 bottom: 0;
 top: 0;
 display: flex;
 justify-content: center;
 align-items: center;
 `)]),j("name",`
 color: var(--n-item-text-color);
 flex: 1;
 display: flex;
 justify-content: center;
 text-overflow: ellipsis;
 overflow: hidden;
 flex-direction: column;
 text-decoration-color: #0000;
 font-size: var(--n-font-size);
 transition:
 color .3s var(--n-bezier),
 text-decoration-color .3s var(--n-bezier); 
 `,[L("a",`
 color: inherit;
 text-decoration: underline;
 `)])])])]),f("upload-file-input",`
 display: block;
 width: 0;
 height: 0;
 opacity: 0;
 `)]);var ae=globalThis&&globalThis.__awaiter||function(e,i,n,t){function o(s){return s instanceof n?s:new n(function(u){u(s)})}return new(n||(n=Promise))(function(s,u){function m(a){try{l(t.next(a))}catch(c){u(c)}}function d(a){try{l(t.throw(a))}catch(c){u(c)}}function l(a){a.done?s(a.value):o(a.value).then(m,d)}l((t=t.apply(e,i||[])).next())})};function hr(e,i,n){const{doChange:t,xhrMap:o}=e;let s=0;function u(d){var l;let a=Object.assign({},i,{status:"error",percentage:s});o.delete(i.id),a=X(((l=e.onError)===null||l===void 0?void 0:l.call(e,{file:a,event:d}))||a),t(a,d)}function m(d){var l;if(e.isErrorState){if(e.isErrorState(n)){u(d);return}}else if(n.status<200||n.status>=300){u(d);return}let a=Object.assign({},i,{status:"finished",percentage:s});o.delete(i.id),a=X(((l=e.onFinish)===null||l===void 0?void 0:l.call(e,{file:a,event:d}))||a),t(a,d)}return{handleXHRLoad:m,handleXHRError:u,handleXHRAbort(d){const l=Object.assign({},i,{status:"removed",file:null,percentage:s});o.delete(i.id),t(l,d)},handleXHRProgress(d){const l=Object.assign({},i,{status:"uploading"});if(d.lengthComputable){const a=Math.ceil(d.loaded/d.total*100);l.percentage=a,s=a}t(l,d)}}}function pr(e){const{inst:i,file:n,data:t,headers:o,withCredentials:s,action:u,customRequest:m}=e,{doChange:d}=e.inst;let l=0;m({file:n,data:t,headers:o,withCredentials:s,action:u,onProgress(a){const c=Object.assign({},n,{status:"uploading"}),y=a.percent;c.percentage=y,l=y,d(c)},onFinish(){var a;let c=Object.assign({},n,{status:"finished",percentage:l});c=X(((a=i.onFinish)===null||a===void 0?void 0:a.call(i,{file:c}))||c),d(c)},onError(){var a;let c=Object.assign({},n,{status:"error",percentage:l});c=X(((a=i.onError)===null||a===void 0?void 0:a.call(i,{file:c}))||c),d(c)}})}function mr(e,i,n){const t=hr(e,i,n);n.onabort=t.handleXHRAbort,n.onerror=t.handleXHRError,n.onload=t.handleXHRLoad,n.upload&&(n.upload.onprogress=t.handleXHRProgress)}function ve(e,i){return typeof e=="function"?e({file:i}):e||{}}function vr(e,i,n){const t=ve(i,n);t&&Object.keys(t).forEach(o=>{e.setRequestHeader(o,t[o])})}function br(e,i,n){const t=ve(i,n);t&&Object.keys(t).forEach(o=>{e.append(o,t[o])})}function yr(e,i,n,{method:t,action:o,withCredentials:s,responseType:u,headers:m,data:d}){const l=new XMLHttpRequest;l.responseType=u,e.xhrMap.set(n.id,l),l.withCredentials=s;const a=new FormData;if(br(a,d,n),a.append(i,n.file),mr(e,n,l),o!==void 0){l.open(t.toUpperCase(),o),vr(l,m,n),l.send(a);const c=Object.assign({},n,{status:"uploading"});e.doChange(c)}}const wr=Object.assign(Object.assign({},Q.props),{name:{type:String,default:"file"},accept:String,action:String,customRequest:Function,directory:Boolean,directoryDnd:{type:Boolean,default:void 0},method:{type:String,default:"POST"},multiple:Boolean,showFileList:{type:Boolean,default:!0},data:[Object,Function],headers:[Object,Function],withCredentials:Boolean,responseType:{type:String,default:""},disabled:{type:Boolean,default:void 0},onChange:Function,onRemove:Function,onFinish:Function,onError:Function,onBeforeUpload:Function,isErrorState:Function,onDownload:Function,defaultUpload:{type:Boolean,default:!0},fileList:Array,"onUpdate:fileList":[Function,Array],onUpdateFileList:[Function,Array],fileListStyle:[String,Object],defaultFileList:{type:Array,default:()=>[]},showCancelButton:{type:Boolean,default:!0},showRemoveButton:{type:Boolean,default:!0},showDownloadButton:Boolean,showRetryButton:{type:Boolean,default:!0},showPreviewButton:{type:Boolean,default:!0},listType:{type:String,default:"text"},onPreview:Function,shouldUseThumbnailUrl:{type:Function,default:e=>Ee?he(e):!1},createThumbnailUrl:Function,abstract:Boolean,max:Number,showTrigger:{type:Boolean,default:!0},imageGroupProps:Object,inputProps:Object,triggerStyle:[String,Object],renderIcon:Function}),Br=E({name:"Upload",props:wr,setup(e){e.abstract&&e.listType==="image-card"&&ee("upload","when the list-type is image-card, abstract is not supported.");const{mergedClsPrefixRef:i,inlineThemeDisabled:n}=ue(e),t=Q("Upload","-upload",fr,Ue,e,i),o=De(e),s=C(()=>{const{max:g}=e;return g!==void 0?h.value.length>=g:!1}),u=W(e.defaultFileList),m=O(e,"fileList"),d=W(null),l={value:!1},a=W(!1),c=new Map,y=ze(m,u),h=C(()=>y.value.map(X));function k(){var g;(g=d.value)===null||g===void 0||g.click()}function v(g){const P=g.target;T(P.files?Array.from(P.files).map(S=>({file:S,entry:null,source:"input"})):null,g),P.value=""}function B(g){const{"onUpdate:fileList":P,onUpdateFileList:S}=e;P&&ne(P,g),S&&ne(S,g),u.value=g}const D=C(()=>e.multiple||e.directory);function T(g,P){if(!g||g.length===0)return;const{onBeforeUpload:S}=e;g=D.value?g:[g[0]];const{max:_,accept:U}=e;g=g.filter(({file:z,source:I})=>I==="dnd"&&(U!=null&&U.trim())?He(z.name,z.type,U):!0),_&&(g=g.slice(0,_-h.value.length));const F=ie();Promise.all(g.map(({file:z,entry:I})=>ae(this,void 0,void 0,function*(){var A;const M={id:ie(),batchId:F,name:z.name,status:"pending",percentage:0,file:z,url:null,type:z.type,thumbnailUrl:null,fullPath:(A=I==null?void 0:I.fullPath)!==null&&A!==void 0?A:`/${z.webkitRelativePath||z.name}`};return!S||(yield S({file:M,fileList:h.value}))!==!1?M:null}))).then(z=>ae(this,void 0,void 0,function*(){let I=Promise.resolve();z.forEach(A=>{I=I.then(je).then(()=>{A&&$(A,P,{append:!0})})}),yield I})).then(()=>{e.defaultUpload&&x()})}function x(g){const{method:P,action:S,withCredentials:_,headers:U,data:F,name:z}=e,I=g!==void 0?h.value.filter(M=>M.id===g):h.value,A=g!==void 0;I.forEach(M=>{const{status:K}=M;(K==="pending"||K==="error"&&A)&&(e.customRequest?pr({inst:{doChange:$,xhrMap:c,onFinish:e.onFinish,onError:e.onError},file:M,action:S,withCredentials:_,headers:U,data:F,customRequest:e.customRequest}):yr({doChange:$,xhrMap:c,onFinish:e.onFinish,onError:e.onError,isErrorState:e.isErrorState},z,M,{method:P,action:S,withCredentials:_,responseType:e.responseType,headers:U,data:F}))})}const $=(g,P,S={append:!1,remove:!1})=>{const{append:_,remove:U}=S,F=Array.from(h.value),z=F.findIndex(I=>I.id===g.id);if(_||U||~z){_?F.push(g):U?F.splice(z,1):F.splice(z,1,g);const{onChange:I}=e;I&&I({file:g,fileList:F,event:P}),B(F)}};function p(g){var P;if(g.thumbnailUrl)return g.thumbnailUrl;const{createThumbnailUrl:S}=e;return S?(P=S(g.file,g))!==null&&P!==void 0?P:g.url||"":g.url?g.url:g.file?qe(g.file):""}const b=C(()=>{const{common:{cubicBezierEaseInOut:g},self:{draggerColor:P,draggerBorder:S,draggerBorderHover:_,itemColorHover:U,itemColorHoverError:F,itemTextColorError:z,itemTextColorSuccess:I,itemTextColor:A,itemIconColor:M,itemDisabledOpacity:K,lineHeight:be,borderRadius:ye,fontSize:we,itemBorderImageCardError:xe,itemBorderImageCard:Re}}=t.value;return{"--n-bezier":g,"--n-border-radius":ye,"--n-dragger-border":S,"--n-dragger-border-hover":_,"--n-dragger-color":P,"--n-font-size":we,"--n-item-color-hover":U,"--n-item-color-hover-error":F,"--n-item-disabled-opacity":K,"--n-item-icon-color":M,"--n-item-text-color":A,"--n-item-text-color-error":z,"--n-item-text-color-success":I,"--n-line-height":be,"--n-item-border-image-card-error":xe,"--n-item-border-image-card":Re}}),w=n?ge("upload",void 0,b,e):void 0;Ie(q,{mergedClsPrefixRef:i,mergedThemeRef:t,showCancelButtonRef:O(e,"showCancelButton"),showDownloadButtonRef:O(e,"showDownloadButton"),showRemoveButtonRef:O(e,"showRemoveButton"),showRetryButtonRef:O(e,"showRetryButton"),onRemoveRef:O(e,"onRemove"),onDownloadRef:O(e,"onDownload"),mergedFileListRef:h,triggerStyleRef:O(e,"triggerStyle"),shouldUseThumbnailUrlRef:O(e,"shouldUseThumbnailUrl"),renderIconRef:O(e,"renderIcon"),xhrMap:c,submit:x,doChange:$,showPreviewButtonRef:O(e,"showPreviewButton"),onPreviewRef:O(e,"onPreview"),getFileThumbnailUrlResolver:p,listTypeRef:O(e,"listType"),dragOverRef:a,openOpenFileDialog:k,draggerInsideRef:l,handleFileAddition:T,mergedDisabledRef:o.mergedDisabledRef,maxReachedRef:s,fileListStyleRef:O(e,"fileListStyle"),abstractRef:O(e,"abstract"),acceptRef:O(e,"accept"),cssVarsRef:n?void 0:b,themeClassRef:w==null?void 0:w.themeClass,onRender:w==null?void 0:w.onRender,showTriggerRef:O(e,"showTrigger"),imageGroupPropsRef:O(e,"imageGroupProps"),mergedDirectoryDndRef:C(()=>{var g;return(g=e.directoryDnd)!==null&&g!==void 0?g:e.directory})});const Y={clear:()=>{u.value=[]},submit:x,openOpenFileDialog:k};return Object.assign({mergedClsPrefix:i,draggerInsideRef:l,inputElRef:d,mergedTheme:t,dragOver:a,mergedMultiple:D,cssVars:n?void 0:b,themeClass:w==null?void 0:w.themeClass,onRender:w==null?void 0:w.onRender,handleFileInputChange:v},Y)},render(){var e,i;const{draggerInsideRef:n,mergedClsPrefix:t,$slots:o,directory:s,onRender:u}=this;if(o.default&&!this.abstract){const d=o.default()[0];!((e=d==null?void 0:d.type)===null||e===void 0)&&e[pe]&&(n.value=!0)}const m=r("input",Object.assign({},this.inputProps,{ref:"inputElRef",type:"file",class:`${t}-upload-file-input`,accept:this.accept,multiple:this.mergedMultiple,onChange:this.handleFileInputChange,webkitdirectory:s||void 0,directory:s||void 0}));return this.abstract?r(Fe,null,(i=o.default)===null||i===void 0?void 0:i.call(o),r(Oe,{to:"body"},m)):(u==null||u(),r("div",{class:[`${t}-upload`,n.value&&`${t}-upload--dragger-inside`,this.dragOver&&`${t}-upload--drag-over`,this.themeClass],style:this.cssVars},m,this.showTrigger&&this.listType!=="image-card"&&r(me,null,o),this.showFileList&&r(gr,null,o)))}});export{Br as N,ar as a};
